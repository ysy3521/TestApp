package com.example.testapp;

public class FirebaseID {
    public static String user = "user";
    public static String documentId = "documentId";
    public static String email = "email";
    public static String password = "password";

}
